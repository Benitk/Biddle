package com.example.biddle.Activites;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.biddle.R;

public class UnofferedProductsSellerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unoffered_products_seller);
    }
}